---
name: local-dev-environment
description: "Windows/XAMPP machine facts and tool gotchas for this project (paths, no Python, MySQL repair, escape decoding)"
metadata:
  node_type: memory
  type: reference
  originSessionId: 4dda754f-b204-4de8-967f-4d0b638f61c5
  modified: 2026-10-28T07:51:26.143Z
---

- Local WordPress 7.1.3: `C:\xampp\htdocs\wordpress`, `http://localhost/wordpress`, `WP_ENVIRONMENT_TYPE=local`. Test user `maintenance-auditor`, password in `.env` as `WP_LOCAL_APP_PASSWORD`. Never read the `.env` values.
- PHP: `C:\xampp\php\php.exe` (not on PATH). Python is not installed. Node 24 runs `.ts` directly.
- Start servers in the background with `C:\xampp\mysql\bin\mysqld.exe --defaults-file=mysql/bin/my.ini --standalone` and `C:\xampp\apache\bin\httpd.exe`. Always stop MySQL with `mysqladmin -u root shutdown`, never by killing it: an unclean stop corrupted `mysql/roles_mapping.MAI`. It was fixed on 2026-10-23 from `C:\xampp\mysql\backup\mysql\`; the damaged copies are in `C:\xampp\mysql\roles_mapping-damaged-2026-10-23\`.
- 2026-10-28: MySQL crashed again (InnoDB "LSN in the future", corrupt wpc_manager/wp_terms and mysql.db) after an unclean stop plus two mysqld starts 3 s apart. Fixed by mysqldump of every readable DB → `C:\xampp\mysql\dumps-2026-10-28\`, clean shutdown, old folder kept as `C:\xampp\mysql\data-damaged-2026-10-28\` (+ `wpc_manager-damaged-2026-10-28\`), fresh `data` copied from `mysql\backup`, dumps imported, wpc-manager rebuilt with setup-test-sites + demo-data. Crash details are in the Windows Application event log (source MariaDB, `Get-EventLog`), not in mysql_error.log.
- Tool gotcha: a `\uXXXX` escape written in Write/Edit/Bash content arrives as the real character (it created invisible BOMs once). Build such characters with `String.fromCharCode` in scripts, and scan with a non-ASCII check afterwards.
- Apache started this way is a console process: `httpd.exe -k stop` fails ("No installed service named Apache2.4"), so stop its background task instead.
- Git for Windows has `core.autocrlf=true` system-wide, and Prettier requires LF. The repo's `.gitattributes` (added 2026-10-26) forces LF on checkout, with CRLF only for `*.csv`. GNU grep in Git Bash strips CR before matching, so check line endings with `od -c`.
- Visual PDF check: a renderer is installed only in the session scratchpad (pdf-to-png-converter, with pdfjs-dist for text extraction), so it may need reinstalling.
- Read-only PHP probes of the local site: set `$_SERVER['HTTP_HOST']`/`REQUEST_URI`, require `C:/xampp/htdocs/wordpress/wp-load.php`, run with `C:\xampp\php\php.exe`. A role can be tested in memory only (`$user->caps['x'] = true; $user->get_role_caps();`), nothing is saved. VS Code's PHP extension flags every WordPress function as undefined; use `php -l` instead.
- Simulate a file open in Excel: PowerShell `[System.IO.File]::Open($path, 'Open', 'Read', 'Read')` holds a lock, so a rename over it fails with EPERM.
- The first WordPress request after starting XAMPP can take ~45 s (cold start); later requests ~2 s.
- The auto-mode classifier blocks installing/running downloaded third-party plugin code (tried UpdraftPlus). Read its source instead and use a self-written stand-in.
- Screenshots of wp-admin screens: render the page HTML with PHP CLI into a file that links the site's public CSS, then `chrome.exe --headless=new --screenshot=... file:///...` (Chrome and Edge are installed; headless can't log in).

Related: [[wordpress-maintenance-project]].
