---
name: wp-control-project
description: "Second spec (WP Control PDF) - two WordPress plugins, Manager + Agent, MVP built 2026-10-27 in wp-control/ with 3 local test sites"
metadata:
  node_type: memory
  type: project
  originSessionId: 4dda754f-b204-4de8-967f-4d0b638f61c5
  modified: 2026-10-28T10:17:42.237Z
---

On 2026-10-27 the user sent a new spec PDF, "WP Control – Concept specification": a Manager plugin (agency dashboard in wp-admin, dark UI preview with slide-out site details) and an Agent plugin on every client site. MVP per spec: read-only monitoring, secure pairing, site details, change detection, manual maintenance log linking several detected changes, CSV export. Later (not built): remote updates, run backup, vulnerability scanning, notifications.

Built in `wp-control/` inside this repo (`wp-control-manager/`, `wp-control-agent/`, `tests/`, `tools/`, README). Design: Manager pulls `GET ?rest_route=/wp-control-agent/v1/snapshot`, signed with HMAC-SHA256 (per-site key `wpc1-` + 64 hex, timestamp ±300 s, nonce replay store); the answer is `{payload, signature}`; keys are stored encrypted (sodium secretbox from wp_salt). 12 tables `wp_wpc_*` plus an audit log. Agent plugin version 1.0.0, Manager 1.0.0 (LATEST_AGENT_VERSION constant).

Test sites (created by `tools/setup-test-sites.php`, copies core from C:\xampp\htdocs\wordpress): `wpc-manager`, `wpc-client-a`, `wpc-client-b`, DBs `wpc_manager` / `wpc_client_a` / `wpc_client_b`, login in gitignored `wp-control/.env` (WPC_TEST_USER / WPC_TEST_PASSWORD, moved from test-sites.local.txt on 2026-10-27 at the user's request; never print the password). Clients have DISABLE_WP_CRON + AUTOMATIC_UPDATER_DISABLED so fake update transients stay put. `tests/run-tests.php` (27, resets the sites, copies plugin code in first), `tests/http-check.php` (24), `tools/demo-data.php`. Added 2026-10-28: `tests/soak-and-security.php` (22 security checks + a timed soak, `--minutes N` default 10, `--minutes 0` = security only, `--sync`, stop file `tests/soak.stop`); it is an external HTTP client that signs with each client's real key read via the new `agent-helper.php get-secret` command, read-only, never resets. Gotcha found building it: MySQL CLI via PHP shell_exec on Windows eats `%` in SQL `LIKE` patterns (cmd var expansion), so a `LIKE 'v1:%'` COUNT silently returns 0 — use `LEFT(col,n)=` instead. Also added `tests/load-test.php` (curl_multi concurrency stress test, `--target agent|dashboard|front|all`, `--concurrency`, `--seconds`; reports status buckets, latency p50/p90/p99, conn failures, 5xx, recovery check). Gotcha: to log a concurrent curl handle in, don't hand-parse the cookie jar (curl only flushes the jar on curl_close, and WP auth cookies are HttpOnly) — capture `Set-Cookie` from the login response via CURLOPT_HEADERFUNCTION and resend as a Cookie header.

**Why:** the user wants "full project" builds from specs with "no mistakes", like the first project. Related: [[wordpress-maintenance-project]], [[local-dev-environment]], [[code-style-preferences]].

**How to apply:** keep PHP in WordPress style (tabs, `array()`, namespaced functions, no comments); run both test scripts after every change; bump plugin versions when PHP changes.
