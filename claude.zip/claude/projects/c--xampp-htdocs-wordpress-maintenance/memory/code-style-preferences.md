---
name: code-style-preferences
description: "User wants simple, comment-free, Prettier-formatted code (beginner-friendly; no clever one-liners)"
metadata:
  node_type: memory
  type: feedback
  originSessionId: 4dda754f-b204-4de8-967f-4d0b638f61c5
  modified: 2026-10-23T09:57:03.563Z
---

Write code without comments and keep it Prettier-formatted (`yarn format`; config in `.prettierrc.json`, 120 columns, double quotes). Keep it simple and easy for a beginner to read:
- plain `for` loops and `if/else`;
- small named functions;
- no nested ternaries, no generics where a concrete type works, no `as const` tricks;
- no conditional object spreads (`...(x && {x})`), no `reduce` chains.

**Why:** On 2026-10-21 the user asked to remove all comments and format all code. On 2026-10-23 they asked for "not very hard" code, and later the same day for "every code easier, not very complex, no mistakes".

**How to apply:** New TypeScript and PHP code follows these rules. The one exception is the WordPress plugin header block, which WordPress requires. For refactors, prove the behavior is unchanged: record a golden output before (report definitions, CSV, snapshots, CLI text), compare after, and run `yarn verify`. When undoing a test sabotage, never use a blind `sed` replace; edit using unique surrounding lines. See also [[wordpress-maintenance-project]].
