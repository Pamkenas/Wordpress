---
name: wordpress-maintenance-project
description: "5-week internship spec (Claude Code skill for read-only WordPress maintenance reports); weeks 1-5 done, final review 2026-10-26 (102 tests, plugin 1.0.2), real-site test left to the agency"
metadata:
  node_type: memory
  type: project
  originSessionId: 4dda754f-b204-4de8-967f-4d0b638f61c5
  modified: 2026-10-26T09:36:25.097Z
---

The user builds a 5-week internship MVP: a manually invoked Claude Code skill `wordpress-maintenance`. It collects a read-only WordPress inventory and produces R1 (consolidated PDF + CSV), R2 (internal per site) and R3 (branded client PDF). The spec came as phone screenshots of "WordPress_Maintenance… Project specification": part A is Slovenian (for clients), part B is the English developer spec.

Status on 2026-10-26: weeks 1–5 complete, then a final review the same day found and fixed 7 problems (docs/11 §8): two plugin security holes (auditor with a second role lost the guards; XML-RPC accepted the auditor password), a report crash when a file is open in Excel, `&amp;` in names, `allowInsecureHttp` for any host, no response size limit / control chars / bad timestamps, non-UTF-8 CSV. Now 102 tests; status plugin 1.0.2, also copied to the local XAMPP site. `yarn clean` deletes snapshots/, reports/ and sample-output/. The one open item is the test on 2–3 authorised real client sites (docs/11 §5 checklist). The optional stretch goals were deliberately not built.

The user commits the work themselves (commits named "day 2", "day 3/4", "day 4 update"…), so leave changes uncommitted unless asked. Their "day 3/4" commit deleted `.env.example`; it was restored on 2026-10-26, and a test now checks it.

**Why:** the user asks for work "like in the documentation", week by week, with "no mistakes".

**How to apply:** Map new work to the spec's week list and acceptance tests (§8). Keep the README progress table and the test count in README/docs 08/10/11 up to date. When the plugin PHP changes, bump its version (header, VERSION const, readme.txt) so older site copies show as an update. Client-facing R3 is in Slovenian by default (`agency.json` language). Related: [[code-style-preferences]], [[local-dev-environment]].
